/**
 * 
 */
package com.xebia.generatebill.constants;

/**
 * @author Ravi
 *
 */
public enum UserType {
	
	EMPLOYEE(30),
	STORE_AFFILIATE(10),
	LOYAL_CUSTOMER(5),
	;
	
	private int discount;
	
	private UserType(int discount) {
		this.discount = discount;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
}
