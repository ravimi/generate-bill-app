package com.xebia.generatebill.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.xebia.generatebill.constants.ItemCategory;
import com.xebia.generatebill.constants.UserType;

public class TotalBill {
	
	private BigDecimal totalAmount;
	private UserType userType;
	private BigDecimal netPayable;
	private ItemCategory itemCategory;
	private List<Discount> discounts;
	
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public BigDecimal getNetPayable() {
		return netPayable;
	}
	public void setNetPayable(BigDecimal netPayable) {
		this.netPayable = netPayable;
	}
	public ItemCategory getItemCategory() {
		return itemCategory;
	}
	public void setItemCategory(ItemCategory itemCategory) {
		this.itemCategory = itemCategory;
	}
	public List<Discount> getDiscounts() {
		if(null == discounts) return new ArrayList<Discount>();
		return discounts;
	}
	public void setDiscounts(List<Discount> discounts) {
		this.discounts = discounts;
	}
}
