package com.xebia.generatebill.constants;

public enum ItemCategory {
	
	GROCERY, NONGROCERY;
	
}
