/**
 * 
 */
package com.xebia.generatebill.services;

import java.time.Instant;
import java.util.List;

import com.xebia.generatebill.data.Item;
import com.xebia.generatebill.data.Order;
import com.xebia.generatebill.data.User;

/**
 * @author Ravi
 *
 */
public class OrderService {
	
	public Order createOrder(List<Item> items, User user) {
		Order order = new Order();
		order.setItems(items);
		order.setOrderDateTime(Instant.now());
		order.setOrderBy(user);
		return order;
	}
	
	public boolean saveOrder() {
		//logic for order persisting
		return true;
	}
	
	public boolean updateOrder() {
		//logic for order updation
		return true;
	}
	
	public static void main(String[] args) {
		
	}
	
	private static Order createOrderForTesting() {
		return null;
	}
}
