/**
 * 
 */
package com.xebia.generatebill.data;

import java.math.BigDecimal;

import com.xebia.generatebill.constants.ItemCategory;

/**
 * @author Ravi
 *
 */
public class Item {
	
	private String name;
	private BigDecimal costPrice;
	private BigDecimal salePrice;
	private ItemCategory category;
	private Discount discountIfApplicable;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getCostPrice() {
		return costPrice;
	}
	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}
	public BigDecimal getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(BigDecimal salePrice) {
		this.salePrice = salePrice;
	}
	public ItemCategory getCategory() {
		return category;
	}
	public void setCategory(ItemCategory category) {
		this.category = category;
	}
	public Discount getDiscountIfApplicable() {
		return discountIfApplicable;
	}
	public void setDiscountIfApplicable(Discount discountIfApplicable) {
		this.discountIfApplicable = discountIfApplicable;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((costPrice == null) ? 0 : costPrice.hashCode());
		result = prime * result + ((discountIfApplicable == null) ? 0 : discountIfApplicable.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((salePrice == null) ? 0 : salePrice.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (category != other.category)
			return false;
		if (costPrice == null) {
			if (other.costPrice != null)
				return false;
		} else if (!costPrice.equals(other.costPrice))
			return false;
		if (discountIfApplicable == null) {
			if (other.discountIfApplicable != null)
				return false;
		} else if (!discountIfApplicable.equals(other.discountIfApplicable))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (salePrice == null) {
			if (other.salePrice != null)
				return false;
		} else if (!salePrice.equals(other.salePrice))
			return false;
		return true;
	}
}
