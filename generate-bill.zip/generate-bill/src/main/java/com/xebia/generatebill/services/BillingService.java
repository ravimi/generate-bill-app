package com.xebia.generatebill.services;

import java.math.BigDecimal;
import java.util.List;

import com.xebia.generatebill.data.Discount;
import com.xebia.generatebill.data.Item;
import com.xebia.generatebill.data.Order;
import com.xebia.generatebill.data.TotalBill;
import com.xebia.generatebill.data.User;

public class BillingService {
	
	public TotalBill calculateOrderBill(Order order, User user) throws SystemException {
		TotalBill bill = new TotalBill();
		BigDecimal amount = new BigDecimal(0);
		if(null == order) {
			throw new SystemException("Order must not be null");
		}
		if(order.getItems().stream().count() <= 0) {
			throw new SystemException("There is no item in order");
		}
		for (Item item : order.getItems()) {
			if(null == item.getSalePrice()) continue;
			BigDecimal price = item.getSalePrice();
			amount.add(price);
		}
		bill.setTotalAmount(amount);
		bill.setNetPayable(amount);
		bill.setUserType(user.getType());
		return bill;
	}
	
	TotalBill applyUserDiscountOnTotalBill(TotalBill bill, List<Discount> discounts) {
		int userDiscount = bill.getUserType().getDiscount();
		Discount discount = new Discount(bill.getUserType().toString(), bill.getUserType().getDiscount()+"", "%");
		BigDecimal netPayable = bill.getNetPayable();
		BigDecimal applicableDiscount = netPayable.multiply(new BigDecimal(userDiscount)).divide(new BigDecimal(100));
		discount.setAppliedDiscount(applicableDiscount.toString());
		bill.setNetPayable(netPayable.subtract(applicableDiscount));
		discount.setPriceAfterDiscount(netPayable);
		discounts.add(discount);
		return bill;
	}
	
	TotalBill applyBulkDiscountDiscountedBill(TotalBill bill, int onUnit, int unit) {
		Discount discount = new Discount("Every $100 Bill", "$5", "Every $100");
		BigDecimal netPayable = bill.getNetPayable();
		int multiplier = getPerUnitDiscountMultiplier(netPayable, unit);
		int applicableDiscount = multiplier * onUnit;
		bill.setNetPayable(netPayable.subtract(new BigDecimal(applicableDiscount)));
		bill.getDiscounts().add(discount);
		return bill;
	}
	
	private int getPerUnitDiscountMultiplier(BigDecimal amount, int perUnit) {
		return amount.divide(new BigDecimal(perUnit)).intValue();
	}
	
	public static void main(String[] args) {
		BigDecimal amount = new BigDecimal(995);
		int multiplier = new BillingService().getPerUnitDiscountMultiplier(amount, 100);
		System.out.println(multiplier);
	}
}
