/**
 * 
 */
package com.xebia.generatebill.data;

import java.math.BigDecimal;

/**
 * @author Ravi
 *
 */
public class Discount {
	
	private String discountName;
	private String applicableDiscount;
	private String discountType;
	private BigDecimal priceAfterDiscount;
	private String appliedDiscount;
	
	public Discount() {
	}
	
	public Discount(String discountName, String applicableDiscount, String discountType) {
		super();
		this.discountName = discountName;
		this.applicableDiscount = applicableDiscount;
		this.discountType = discountType;
	}
	
	public String getDiscountName() {
		return discountName;
	}
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}
	public String getApplicableDiscount() {
		return applicableDiscount;
	}
	public void setApplicableDiscount(String applicableDiscount) {
		this.applicableDiscount = applicableDiscount;
	}
	public String getDiscountType() {
		return discountType;
	}
	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}
	
	public BigDecimal getPriceAfterDiscount() {
		return priceAfterDiscount;
	}

	public void setPriceAfterDiscount(BigDecimal priceAfterDiscount) {
		this.priceAfterDiscount = priceAfterDiscount;
	}

	public String getAppliedDiscount() {
		return appliedDiscount;
	}

	public void setAppliedDiscount(String appliedDiscount) {
		this.appliedDiscount = appliedDiscount;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((applicableDiscount == null) ? 0 : applicableDiscount.hashCode());
		result = prime * result + ((appliedDiscount == null) ? 0 : appliedDiscount.hashCode());
		result = prime * result + ((discountName == null) ? 0 : discountName.hashCode());
		result = prime * result + ((discountType == null) ? 0 : discountType.hashCode());
		result = prime * result + ((priceAfterDiscount == null) ? 0 : priceAfterDiscount.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Discount other = (Discount) obj;
		if (applicableDiscount == null) {
			if (other.applicableDiscount != null)
				return false;
		} else if (!applicableDiscount.equals(other.applicableDiscount))
			return false;
		if (appliedDiscount == null) {
			if (other.appliedDiscount != null)
				return false;
		} else if (!appliedDiscount.equals(other.appliedDiscount))
			return false;
		if (discountName == null) {
			if (other.discountName != null)
				return false;
		} else if (!discountName.equals(other.discountName))
			return false;
		if (discountType == null) {
			if (other.discountType != null)
				return false;
		} else if (!discountType.equals(other.discountType))
			return false;
		if (priceAfterDiscount == null) {
			if (other.priceAfterDiscount != null)
				return false;
		} else if (!priceAfterDiscount.equals(other.priceAfterDiscount))
			return false;
		return true;
	}
}
