/**
 * 
 */
package com.xebia.generatebill.data;

/**
 * @author Ravi
 *
 */
public class Address {
	
	private String flatBuilding;
	private String gali;
	private String locality;
	private String state;
	private String pinCode;
	private String landMark;
	
	public String getFlatBuilding() {
		return flatBuilding;
	}
	public void setFlatBuilding(String flatBuilding) {
		this.flatBuilding = flatBuilding;
	}
	public String getGali() {
		return gali;
	}
	public void setGali(String gali) {
		this.gali = gali;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getLandMark() {
		return landMark;
	}
	public void setLandMark(String landMark) {
		this.landMark = landMark;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((flatBuilding == null) ? 0 : flatBuilding.hashCode());
		result = prime * result + ((gali == null) ? 0 : gali.hashCode());
		result = prime * result + ((landMark == null) ? 0 : landMark.hashCode());
		result = prime * result + ((locality == null) ? 0 : locality.hashCode());
		result = prime * result + ((pinCode == null) ? 0 : pinCode.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (flatBuilding == null) {
			if (other.flatBuilding != null)
				return false;
		} else if (!flatBuilding.equals(other.flatBuilding))
			return false;
		if (gali == null) {
			if (other.gali != null)
				return false;
		} else if (!gali.equals(other.gali))
			return false;
		if (landMark == null) {
			if (other.landMark != null)
				return false;
		} else if (!landMark.equals(other.landMark))
			return false;
		if (locality == null) {
			if (other.locality != null)
				return false;
		} else if (!locality.equals(other.locality))
			return false;
		if (pinCode == null) {
			if (other.pinCode != null)
				return false;
		} else if (!pinCode.equals(other.pinCode))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}
}
