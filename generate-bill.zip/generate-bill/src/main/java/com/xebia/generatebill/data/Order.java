package com.xebia.generatebill.data;

import java.time.Instant;
import java.util.List;

public class Order {
	
	private List<Item> items;
	private Instant orderDateTime;
	private User orderBy;
	private TotalBill bill;
	
	public List<Item> getItems() {
		return items;
	}
	public void setItems(List<Item> items) {
		this.items = items;
	}
	public Instant getOrderDateTime() {
		return orderDateTime;
	}
	public void setOrderDateTime(Instant orderDateTime) {
		this.orderDateTime = orderDateTime;
	}
	public User getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(User orderBy) {
		this.orderBy = orderBy;
	}

	public TotalBill getBill() {
		return bill;
	}
	public void setBill(TotalBill bill) {
		this.bill = bill;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bill == null) ? 0 : bill.hashCode());
		result = prime * result + ((items == null) ? 0 : items.hashCode());
		result = prime * result + ((orderBy == null) ? 0 : orderBy.hashCode());
		result = prime * result + ((orderDateTime == null) ? 0 : orderDateTime.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (bill == null) {
			if (other.bill != null)
				return false;
		} else if (!bill.equals(other.bill))
			return false;
		if (items == null) {
			if (other.items != null)
				return false;
		} else if (!items.equals(other.items))
			return false;
		if (orderBy == null) {
			if (other.orderBy != null)
				return false;
		} else if (!orderBy.equals(other.orderBy))
			return false;
		if (orderDateTime == null) {
			if (other.orderDateTime != null)
				return false;
		} else if (!orderDateTime.equals(other.orderDateTime))
			return false;
		return true;
	}
}
